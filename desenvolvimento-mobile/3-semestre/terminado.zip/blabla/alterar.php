<?php
include 'conexao.php';

$id          = $_POST['id'];
$nome        = $_POST['nome'];
$login       = $_POST['login'];
$senha       = $_POST['senha'];
$cpf         = $_POST['cpf'];
$email       = $_POST['email'];
$estado      = $_POST['estado'];
$cidade      = $_POST['cidade'];
$bairro      = $_POST['bairro'];
$rua         = $_POST['rua'];
$numeroresid = $_POST['numeroresid'];
$telefone    = $_POST['telefone'];

// CORREÇÃO: Removidos os colchetes [ ] e ajustado o WHERE para usar apenas o ID
$comando = "UPDATE usuario_rl SET 
            NOME_RL = '$nome',
            LOGIN_RL = '$login',
            SENHA_RL = '$senha',
            CPF_RL = '$cpf',
            EMAIL_RL = '$email',
            ESTADO_RL = '$estado',
            CIDADE_RL = '$cidade',
            BAIRRO_RL = '$bairro',
            RUA_RL = '$rua',
            NUMERO_RL = '$numeroresid',
            TELEFONE_RL = '$telefone' 
            WHERE ID_RL = '$id'
            ";

$resulta = mysqli_query($con, $comando);

if ($resulta) {
    mysqli_close($con);
} else {
    // Caso dê erro no banco, exibe o erro real para te ajudar a identificar
    $dados = array("status" => "erro", "detalhe" => mysqli_error($con));
    mysqli_close($con);
    echo json_encode($dados);
}
?>
