<?php
 
    include 'conexao.php';
    
    $cpf=$_POST["cpf"];
	$senha=$_POST["senha"];

	$comando="delete from usuario_rl where CPF_RL='$cpf' and SENHA_RL='$senha'";
	$resulta = mysqli_query($con,$comando);
	$quant = mysqli_affected_rows($con);

	if ($quant>0) {
        $dados=array("status"=>"ok");
    } else { $dados=array("status"=>"erro");}

$close = mysqli_close($con);
echo json_encode($dados);
    
    
 ?>
