<?php
include 'conexao.php';

$nome = $_POST['nome'];
$login = $_POST['login'];
$senha = $_POST['senha'];
$cpf  = $_POST['cpf'];
$email = $_POST['email'];
$estado = $_POST['estado'];
$cidade = $_POST['cidade'];
$bairro = $_POST['bairro'];
$rua = $_POST['rua'];
$numeroresid = $_POST['numeroresid'];
$telefone = $_POST['telefone'];

$comando = "INSERT INTO  usuario_rl (NOME_RL,LOGIN_RL,SENHA_RL,CPF_RL,EMAIL_RL,ESTADO_RL,CIDADE_RL,BAIRRO_RL,RUA_RL,NUMERO_RL,TELEFONE_RL) VALUES ('$nome','$login','$senha','$cpf','$email','$estado','$cidade','$bairro','$rua','$numeroresid','$telefone')";
$resulta = mysqli_query($con, $comando);

if ($resulta) {
    mysqli_close($con);
    
    header('Location: Login.html'); 
    exit;
} else {
    $dados = array("status" => "erro");
    mysqli_close($con);
    echo json_encode($dados);
}
?>


