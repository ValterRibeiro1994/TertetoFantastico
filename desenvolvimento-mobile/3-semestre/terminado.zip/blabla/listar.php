<?php 
include 'conexao.php'; 
try {
    

$comando = "SELECT * FROM usuario_rl"; 
$resulta = mysqli_query($con, $comando); 

$dados = array(); 
while ($r = mysqli_fetch_array($resulta)) { 
    $dados[] = array( 
        'NOME_RL'  => $r[1], 
        'LOGIN_RL' => $r[2], 
        'SENHA_RL'=> $r[3], 
        'CPF_RL' => $r[4],
        'EMAIL_RL'  => $r[5], 
        'ESTADO_RL' => $r[6], 
        'CIDADE_RL'=> $r[7], 
        'BAIRRO_RL' => $r[8],
        'RUA_RL' => $r[9],
        'NUMERO_RL' => $r[10],
        'TELEFONE_RL' => $r[11]
    ); 
} 

mysqli_close($con); 
echo json_encode($dados); 
} catch (Exception $erro){
    echo json_encode(["status"=>false, "erro"=>$erro->getMessage()]);
}
?>
