<?php

header("Content-Type: application/json; charset=UTF-8");

include "conexao.php";



$login = $_POST['login'] ?? '';
$senha = $_POST['senha'] ?? '';

if (empty($login) || empty($senha)) {
    echo json_encode([
        "status" => "erro",
        "mensagem" => "Preencha login e senha."
    ]);
    exit;
}

$comando = "SELECT * FROM usuario_rl WHERE LOGIN_RL = '" . $login . "' AND SENHA_RL = '" . $senha . "'";

$resulta = mysqli_query($con,$comando);

if ($r = mysqli_fetch_assoc($resulta)) {

 

        echo json_encode([
            "status" => "ok",
            "login" => $r["nome_pes"],
            "mensagem" => "Login realizado com sucesso!"
        ]);
        header('Location: listar.html'); 
    exit;

    } else {

        echo json_encode([
            "status" => "erro",
            "mensagem" => "Senha ou usuario incorreta."
        ]);
    }



mysqli_close($con);


?>